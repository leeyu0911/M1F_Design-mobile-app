package com.example.test01;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;

public class OkHttp {

    private OkHttpClient client = null;

    public OkHttp(){
        client = new OkHttpClient();
    }

    public void get(String path, Callback callback){

        Request request;
        request = new Request.Builder()
                .url(path)
                .build();
        Call call = client.newCall(request);
        call.enqueue(callback);
    }
}
