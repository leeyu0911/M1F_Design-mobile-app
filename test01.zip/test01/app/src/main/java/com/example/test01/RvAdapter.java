package com.example.test01;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class RvAdapter extends RecyclerView.Adapter<RvAdapter.RecyclerHolder> {

    private List<String> dataList = new ArrayList<>();
    private Context mContext;


    public RvAdapter(Context mContext, List<String> dataList) {
        this.mContext = mContext;
        this.dataList = dataList;
    }

    public void addData(List<String> dataList) {
        if (null != dataList) {
            this.dataList.addAll(dataList);
            notifyDataSetChanged();
        }
    }

    public void setData(List<String> dataList) {
        if (null != dataList) {
            this.dataList.clear();
            this.dataList.addAll(dataList);
            notifyDataSetChanged();
        }
    }

    @Override
    public RecyclerHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.layout_linear_item, parent, false);
        return new RecyclerHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerHolder holder, int position) {
        holder.textView.setText(dataList.get(position));
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    class RecyclerHolder extends RecyclerView.ViewHolder {
        public TextView textView;

        private RecyclerHolder(View itemView) {
            super(itemView);
            textView = itemView.findViewById(R.id.title);
        }
    }

}

//public class RvAdapter extends RecyclerView.Adapter<RvAdapter.RecyclerHolder> {
//
//    private Context mContext;
//    private List<String> datalist = new ArrayList<>();
//
//    public RvAdapter(Context context,List<String> datalist){
//        this.mContext = context;
//        this.datalist = datalist;
//    }
//
//    //implemet adddata
//    public void addData(List<String> datalist){
//        if(null != datalist){
//            this.datalist.addAll(datalist);
//            notifyDataSetChanged();
//        }
//    }
//
//    public void setData(List<String> datalist) {
//        if(null != datalist){
//            this.datalist.clear();
//            this.datalist.addAll(datalist);
//            notifyDataSetChanged();
//        }
//    }
//
//    @NonNull
//    @Override
//    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
//        View view = LayoutInflater.from(mContext).inflate(R.layout.item, parent, false);
//        return new RecyclerView.ViewHolder(view);
//    }
//
//    @Override
//    public void onBindViewHolder(@NonNull RvAdapter.RecyclerHolder holder, int position) {
//
//    }
//
//    @Override
//    public void onBindViewHolder(@NonNull RvAdapter.LinearViewHolder holder, int position) {
//        holder.textView.setText("HelloViewHolder");
////        holder.itemView.setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View v) {
////                //
////            }
////        });
//    }
//
//    @Override
//    public int getItemCount() {
//        return 0;
//    }
//
//    class LinearViewHolder extends RecyclerView.ViewHolder{
//
//        private TextView textView;
//
//        public LinearViewHolder(@NonNull View itemView) {
//            super(itemView);
//            textView = itemView.findViewById(R.id.title);
//        }
//    }
//}
