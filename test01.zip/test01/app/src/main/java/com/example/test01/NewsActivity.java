package com.example.test01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.text.TextUtils;
import android.text.util.Linkify;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.Button;
import android.widget.TextView;

public class NewsActivity extends AppCompatActivity {

    private TextView mSince,mTitle,mContent;
    private Button mbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);
        mbtn = (Button)findViewById(R.id.btnback2);
        mbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NewsActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
        mSince = (TextView)findViewById(R.id.news_since);
        mSince.setText("2020-12-24 23:36:28");
        mTitle = (TextView)findViewById(R.id.news_title);
        mTitle.setText("[本校公告]  舊版個人郵件系統及舊版公務郵件系統預計於2020/12/31下線，如有舊系統資料尚未完成備份請於此期限前完成。");
        mTitle.getViewTreeObserver().addOnGlobalLayoutListener(new OnTvGlobalLayoutListener());
        mContent = (TextView)findViewById(R.id.news_content);
        mContent.setAutoLinkMask(Linkify.ALL);
        mContent.setText("轉知所屬計網中心公告：\n[說明]:\n一、        舊版個人郵件系統及舊版公務郵件系統預計於 2020/12/31凌晨零時下線關機，本次下線僅關閉舊版網路信箱(Webmail)，不會影響原本網域(@emai.ncku.edu.tw)及(@mail.ncku.edu.tw)之收發信功能。\n二、        舊版個人、學生郵件系統登入網址(2020/12/31下線): http://oldmail.ncku.edu.tw/\n三、        舊版公務郵件系統登入網址(2020/12/31下線): http://oldemail.ncku.edu.tw/\n四、        新版郵件系統登入網址: https://mail.ncku.edu.tw/cgi-bin/login?index=1\n五、        舊版郵件系統信件資料已全數轉換至新版郵件系統，如有舊系統資料轉換問題或其他疑問，請盡速與本中心洽詢 (校內分機61010，Email: mailservice@ncku.edu.tw)\n");
    }

    private class OnTvGlobalLayoutListener implements ViewTreeObserver.OnGlobalLayoutListener {
        @Override
        public void onGlobalLayout() {
            mTitle.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            //mContent.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            final String newText = autoSplitText(mTitle);
            //final String newText2 = autoSplitText(mContent);
            if (!TextUtils.isEmpty(newText)) {
                mTitle.setText(newText);
                //mContent.setText(newText2);
            }
        }
    }

    private String autoSplitText(final TextView tv) {
        final String rawText = tv.getText().toString(); //原始文字
        final Paint tvPaint = tv.getPaint(); //paint，包含字型等資訊
        final float tvWidth = tv.getWidth() - tv.getPaddingLeft() - tv.getPaddingRight(); //控制元件可用寬度

        //將原始文字按行拆分
        String[] rawTextLines = rawText.replaceAll("\r", "").split("\n");
        StringBuilder sbNewText = new StringBuilder();
        for (String rawTextLine : rawTextLines) {
            if (tvPaint.measureText(rawTextLine) <= tvWidth) {
                //如果整行寬度在控制元件可用寬度之內，就不處理了
                sbNewText.append(rawTextLine);
            } else {
                //如果整行寬度超過控制元件可用寬度，則按字元測量，在超過可用寬度的前一個字元處手動換行
                float lineWidth = 0;
                for (int cnt = 0; cnt != rawTextLine.length(); ++cnt) {
                    char ch = rawTextLine.charAt(cnt);
                    lineWidth += tvPaint.measureText(String.valueOf(ch));
                    if (lineWidth <= tvWidth) {
                        sbNewText.append(ch);
                    } else {
                        sbNewText.append("\n");
                        lineWidth = 0;
                        --cnt;
                    }
                }
            }
            sbNewText.append("\n");
        }

        //把結尾多餘的\n去掉
        if (!rawText.endsWith("\n")) {
            sbNewText.deleteCharAt(sbNewText.length() - 1);
        }

        return sbNewText.toString();
    }
}
