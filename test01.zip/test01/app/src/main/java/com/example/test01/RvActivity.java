package com.example.test01;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;

import com.jcodecraeer.xrecyclerview.ProgressStyle;
import com.jcodecraeer.xrecyclerview.XRecyclerView;

import java.util.ArrayList;
import java.util.List;

public class RvActivity extends AppCompatActivity {

    private XRecyclerView mRv;
    private RvAdapter mAdp;
    private Button mBtn;

    private List<String> dataList = new ArrayList<>();

    private List<String> testList() {
        List<String> mytest = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            mytest.add("test" + System.currentTimeMillis());
        }
        return mytest;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rv);
        mBtn = (Button) findViewById(R.id.btnback);
        mBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RvActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
        mRv = findViewById(R.id.rv);
        mRv.addItemDecoration(new MyDecoration());
        mAdp = new RvAdapter(this, dataList);

        // XRecyclerView的使用，和RecyclerView几乎一致
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRv.setLayoutManager(layoutManager);
        //mRv.addItemDecoration(new MyDecoration());
        mRv.setAdapter(mAdp);
        // 可以设置是否开启加载更多/下拉刷新
        mRv.setLoadingMoreEnabled(true);
        // 可以设置加载更多的样式，很多种
        mRv.setLoadingMoreProgressStyle(ProgressStyle.Pacman);
        // 如果设置上这个，下拉刷新的时候会显示上次刷新的时间
        mRv.getDefaultRefreshHeaderView() // get default refresh header view
                .setRefreshTimeVisible(true);  // make refresh time visible,false means hiding

        // 添加数据
        mAdp.addData(testList());

        // 添加刷新和加载更多的监听
        mRv.setLoadingListener(new XRecyclerView.LoadingListener() {
            @Override
            public void onRefresh() {
                mAdp.setData(testList());
                // 为了看效果，加了一个等待效果，正式的时候直接写mRecyclerView.refreshComplete();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        mRv.refreshComplete();
                    }
                }, 2000);
            }

            @Override
            public void onLoadMore() {
                mAdp.addData(testList());
                // 为了看效果，加了一个等待效果，正式的时候直接写mRecyclerView.loadMoreComplete();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        mRv.loadMoreComplete();
                    }
                }, 2000);
            }
        });
    }

    private class MyDecoration extends RecyclerView.ItemDecoration {
        @Override
        public void getItemOffsets(@NonNull Rect outRect, @NonNull View view, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
            super.getItemOffsets(outRect, view, parent, state);
            outRect.set(0, 0, 0, getResources().getDimensionPixelOffset(R.dimen.deviderHeight));
        }
    }
}
