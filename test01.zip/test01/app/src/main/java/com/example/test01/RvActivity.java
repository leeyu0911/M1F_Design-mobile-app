package com.example.test01;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;

import com.jcodecraeer.xrecyclerview.ProgressStyle;
import com.jcodecraeer.xrecyclerview.XRecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class RvActivity extends AppCompatActivity {

    private XRecyclerView mRv;
    private RvAdapter mAdp;
    private Button mBtn;

    private List<String> dataList = new ArrayList<>();
    private List<String> titlelist = new ArrayList<String>();
    private List<String> statuslist = new ArrayList<String>();
    private List<String> sincelist = new ArrayList<String>();

    public Callback callback = new Callback() {
        @Override
        public void onFailure(Call call, IOException e) {
            Log.e("CSIE", e.getMessage());
        }

        @Override
        public void onResponse(Call call, final Response response) throws IOException {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {

                        //取得JSON標籤
                        String result = response.body().string();
                        JSONArray array = new JSONArray(result);
                        for (int i = 0; i < array.length(); i++) {
                            JSONObject jsonObject = array.getJSONObject(i);
                            String aid = jsonObject.getString("AID");
                            String title = jsonObject.getString("Title");
                            String content = jsonObject.getString("Content");
                            String type = jsonObject.getString("Type");
                            String status = jsonObject.getString("Status");
                            String author = jsonObject.getString("Author");
                            String since = jsonObject.getString("Since");

                            //刪除html標籤
                            content = content.replaceAll("&nbsp;", " ");
                            String regEx_html = "<[^>]+>";
                            String regEx_td = "<[td]+>";
                            String regEx_tr = "<[tr]+>";
                            Pattern p_html = Pattern.compile(regEx_td, Pattern.CASE_INSENSITIVE);
                            Matcher m_html = p_html.matcher(content);
                            content = m_html.replaceAll(" ");

                            p_html = Pattern.compile(regEx_tr, Pattern.CASE_INSENSITIVE);
                            m_html = p_html.matcher(content);
                            content = m_html.replaceAll("\n");

                            p_html = Pattern.compile(regEx_html, Pattern.CASE_INSENSITIVE);
                            m_html = p_html.matcher(content);
                            content = m_html.replaceAll("");

                            //存入ArrayList
                            titlelist.add(title);
                            statuslist.add(status);
                            sincelist.add(since);
                        }

                        //List上顯示
                        //ListView listView = (ListView) findViewById(R.id.listView);
                        //ListAdapter listAdapter = new ArrayAdapter<String>(MainActivity.this, android.R.layout.simple_list_item_1, titlelist);
                        //listView.setAdapter(listAdapter);

                    } catch (JSONException | IOException e) {
                        e.printStackTrace();
                    }
                }
            });
        }
    };

    private List<String> testList() {
        return titlelist;
    }
    private List<String> testList1() {
        List<String> mytest = new ArrayList<>();
        for(int i = 0 ; i<10; i++){
            mytest.add("test"+i);
        }
        return mytest;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rv);
        //建立連線
        OkHttp okhttp = new OkHttp();
        okhttp.get("https://www.tuuuna.com/api/getapplist?cid=4&page=0", callback);

        mBtn = (Button) findViewById(R.id.btnback);
        mBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RvActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
        mRv = findViewById(R.id.rv);
        mRv.addItemDecoration(new MyDecoration());
        mAdp = new RvAdapter(this, dataList);

        // XRecyclerView的使用，和RecyclerView几乎一致
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        mRv.setLayoutManager(layoutManager);
        //mRv.addItemDecoration(new MyDecoration());
        mRv.setAdapter(mAdp);
        // 可以设置是否开启加载更多/下拉刷新
        mRv.setLoadingMoreEnabled(true);
        // 可以设置加载更多的样式，很多种
        mRv.setLoadingMoreProgressStyle(ProgressStyle.Pacman);
        // 如果设置上这个，下拉刷新的时候会显示上次刷新的时间
        mRv.getDefaultRefreshHeaderView() // get default refresh header view
                .setRefreshTimeVisible(true);  // make refresh time visible,false means hiding

        // 添加数据
        mAdp.addData(testList());

        // 添加刷新和加载更多的监听
        mRv.setLoadingListener(new XRecyclerView.LoadingListener() {
            @Override
            public void onRefresh() {
                mAdp.setData(testList());
                // 为了看效果，加了一个等待效果，正式的时候直接写mRecyclerView.refreshComplete();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        mRv.refreshComplete();
                    }
                }, 2000);
            }

            @Override
            public void onLoadMore() {
                mAdp.addData(testList());
                // 为了看效果，加了一个等待效果，正式的时候直接写mRecyclerView.loadMoreComplete();
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        mRv.loadMoreComplete();
                    }
                }, 2000);
            }
        });
    }

    private class MyDecoration extends RecyclerView.ItemDecoration {
        @Override
        public void getItemOffsets(@NonNull Rect outRect, @NonNull View view, @NonNull RecyclerView parent, @NonNull RecyclerView.State state) {
            super.getItemOffsets(outRect, view, parent, state);
            outRect.set(0, 0, 0, getResources().getDimensionPixelOffset(R.dimen.deviderHeight));
        }
    }
}
